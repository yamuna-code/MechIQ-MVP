#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// ── Pin definitions
#define ALERT_LED 4

// ── Sensor object (replaces ADXL345 + MLX90614)
Adafruit_MPU6050 mpu;

// ── Baseline (learned during observation period)
float baseline_rms = 0.0;
float baseline_temp = 0.0;
int sample_count = 0;
bool learning_mode = true;
int learning_samples = 50;

// ── Anomaly detection parameters
float VIBRATION_THRESHOLD_MULTIPLIER = 2.0;
float TEMP_THRESHOLD_DELTA = 5.0;

// ── Feature storage
float rms_values[50];
int feature_index = 0;

float calculateRMS(float x, float y, float z) {
  return sqrt((x * x + y * y + z * z) / 3.0);
}

float calculateKurtosis(float* data, int n) {
  float mean = 0, variance = 0, fourth_moment = 0;
  for (int i = 0; i < n; i++) mean += data[i];
  mean /= n;
  for (int i = 0; i < n; i++) {
    float diff = data[i] - mean;
    variance += diff * diff;
    fourth_moment += diff * diff * diff * diff;
  }
  variance /= n;
  fourth_moment /= n;
  if (variance == 0) return 0;
  return fourth_moment / (variance * variance);
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22); // SDA=21, SCL=22 for ESP32-S3

  pinMode(ALERT_LED, OUTPUT);

  Serial.println("==============================");
  Serial.println("  AffordSense PdM System v1.0");
  Serial.println("==============================");
  Serial.println("Initialising sensors...");

  if (!mpu.begin()) {
    Serial.println("ERROR: MPU6050 not found. Check wiring.");
    while (1);
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_16_G);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  Serial.println("[OK] MPU6050 vibration + temperature sensor ready");

  Serial.println("\n--- OBSERVATION MODE: Learning baseline (50 samples) ---");
  Serial.println("Format: Sample | RMS (g) | Temp (C) | Mode");
  delay(1000);
}

void loop() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  float x = a.acceleration.x;
  float y = a.acceleration.y;
  float z = a.acceleration.z;
  float rms = calculateRMS(x, y, z);
  float t = temp.temperature; // onboard chip temperature — proxy signal

  if (feature_index < 50) {
    rms_values[feature_index] = rms;
    feature_index = (feature_index + 1) % 50;
  }

  float kurtosis = calculateKurtosis(rms_values, 50);

  if (learning_mode) {
    baseline_rms = ((baseline_rms * sample_count) + rms) / (sample_count + 1);
    baseline_temp = ((baseline_temp * sample_count) + t) / (sample_count + 1);
    sample_count++;

    Serial.print("Sample "); Serial.print(sample_count);
    Serial.print(" | RMS: "); Serial.print(rms, 3);
    Serial.print(" g | Temp: "); Serial.print(t, 1);
    Serial.print(" C | Baseline RMS: "); Serial.print(baseline_rms, 3);
    Serial.println(" g | [LEARNING]");

    digitalWrite(ALERT_LED, LOW);

    if (sample_count >= learning_samples) {
      learning_mode = false;
      Serial.println("\n--- OBSERVATION COMPLETE ---");
      Serial.print("Baseline RMS: "); Serial.print(baseline_rms, 3); Serial.println(" g");
      Serial.print("Baseline Temp: "); Serial.print(baseline_temp, 1); Serial.println(" C");
      Serial.println("--- ALERT MODE ACTIVE ---\n");
      Serial.println("Format: RMS | Temp | Kurtosis | Anomaly Score | Status");
    }

  } else {
    float vib_ratio = rms / baseline_rms;
    float temp_delta = t - baseline_temp;

    float vib_score = (rms - baseline_rms) / (baseline_rms * 0.1 + 0.001);
    float temp_score = temp_delta / 2.0;
    float kurt_score = (kurtosis > 3.0) ? (kurtosis - 3.0) : 0;
    float anomaly_score = (vib_score * 0.5) + (temp_score * 0.3) + (kurt_score * 0.2);

    bool vib_alert  = vib_ratio > VIBRATION_THRESHOLD_MULTIPLIER;
    bool temp_alert = temp_delta > TEMP_THRESHOLD_DELTA;
    bool kurt_alert = kurtosis > 4.5;
    bool two_sensor_agree = (vib_alert && temp_alert) ||
                             (vib_alert && kurt_alert) ||
                             (temp_alert && kurt_alert);

    Serial.print("RMS: "); Serial.print(rms, 3);
    Serial.print(" g | Temp: "); Serial.print(t, 1);
    Serial.print(" C | Kurt: "); Serial.print(kurtosis, 2);
    Serial.print(" | Score: "); Serial.print(anomaly_score, 2);

    if (two_sensor_agree && anomaly_score > 2.0) {
      Serial.println(" | TIER-3 CRITICAL - Check main bearing immediately");
      for (int i = 0; i < 3; i++) {
        digitalWrite(ALERT_LED, HIGH); delay(100);
        digitalWrite(ALERT_LED, LOW);  delay(100);
      }
    } else if (vib_alert || temp_alert) {
      Serial.println(" | TIER-1 ADVISORY - Unusual pattern detected");
      digitalWrite(ALERT_LED, HIGH); delay(300);
      digitalWrite(ALERT_LED, LOW);
    } else {
      Serial.println(" | NORMAL");
      digitalWrite(ALERT_LED, LOW);
    }
  }

  delay(500);
}